# CVIP ASSIGNMENT2 > 2022-11-27 12:30am
https://universe.roboflow.com/203-maryam-saleem-84zbc/cvip-assignment2

Provided by a Roboflow user
License: CC BY 4.0

